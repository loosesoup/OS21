#include  <stdio.h>
#include  <sys/types.h>
#include <stdlib.h>

#define   MAX_COUNT  200


void  ChildProcess(int);                /* child process prototype  */
void  ParentProcess(void);               /* parent process prototype */

void  main(void){
  
  pid_t  pid;
  int i;
  
  for (i=0;i<2;i++){
     pid = fork();
     if (pid == 0) 
          ChildProcess(i);
     else if(pid > 0) 
          ParentProcess();
     else
       printf("Error");
  }
     
}

void  ChildProcess(int i)
{
    int j;
    
    printf("Child Pid: %d is going to sleep!\n",getpid());
    
    srand(getpid());
    j = rand() % 10;
    sleep(j + 1);
    
    printf("Child Pid: %d is awake!\nWhere is my Parent: %d\n",getpid(),getppid());
    
     
    exit(0);
}

void  ParentProcess(void)
{
     int i,pid,status;
     for (i = 0; i < 2; i++){
       printf("Child Pid: %d i: %d\n",pid,i);
       pid = wait(&status);
       printf("Child Pid: %d has completed\n",pid);
    }
          
  }