#include  <stdio.h>
#include  <stdlib.h>
#include  <sys/types.h>
#include  <sys/ipc.h>
#include  <sys/shm.h>
#include <unistd.h>
#include <sys/wait.h>

//void  ClientProcess(int []);


void Student_Process(int sharedMem[]){
  int i, account;
  
  srand(getpid());
  
  for (i=0;i<25;i++){
    sleep(rand() % 6); // number 0-5
  }
}

void Dad_Process(int sharedMem[]){
  int i, account, val;
  
  srand(getpid());
  
  for (i=0;i<25;i++){
    sleep(rand() % 6); // number 0-5
    account = sharedMem[0];
    
    while(sharedMem[1] !=0);
    if (account <= 100){
      val = rand() % 101; // random val 0-100
      
      if (val % 2 == 0 /*even*/ ){
        account += val;
        printf("Dear old Dad: Deposits $%d / Balance = $%d\n")
      }
      else{
        printf("Dear old Dad: Doesnt have any money to give\n")
      }
      sharedMem[0] = account;
      sharedMem[1] = 1;
    }
    else{
      printf("Dear old Dad: Thinks student has enough Cash \n");
    }
  }
}


int  main(int  argc, char *argv[])
{
     int    ShmID;
     int    *ShmPTR;
     pid_t  pid;
     int    status;

//      if (argc != 5) {
//           printf("Use: %s #1 #2 #3 #4\n", argv[0]);
//           exit(1);
//      }

     ShmID = shmget(IPC_PRIVATE, 2*sizeof(int), IPC_CREAT | 0666);
     if (ShmID < 0) {
          printf("*** shmget error (server) ***\n");
          exit(1);
     }
     printf("Server has received a shared memory of four integers...\n");

     ShmPTR = (int *) shmat(ShmID, NULL, 0);
     if (*ShmPTR == -1) {
          printf("*** shmat error (server) ***\n");
          exit(1);
     }
     printf("Server has attached the shared memory...\n");

     ShmPTR[0] = 0; //bank
     ShmPTR[1] = 0; //turn
     
     printf("Main has filled bank account = %d turn = %d in shared memory...\n",
            ShmPTR[0], ShmPTR[1]);

     printf("Server is about to fork a child process...\n");
     pid = fork();
  // DONT KNOW iF RIGHT AFTER THIS
     if (pid < 0) {
          printf("*** fork error (server) ***\n");
          exit(1);
     }
     else if (pid == 0) {
          Student_Process(ShmPTR);
          exit(0);
     }
     else{
          Dad_Process(ShmPTR);
     }

     wait(&status);
     
}

void  ClientProcess(int  SharedMem[])
{
     printf("   Client process started\n");
     printf("   Client found %d %d %d %d in shared memory\n",
                SharedMem[0], SharedMem[1], SharedMem[2], SharedMem[3]);
     printf("   Client is about to exit\n");
}