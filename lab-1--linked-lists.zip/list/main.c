#include <stdio.h>

#include "list.h"

int main() {
  printf("Tests for linked list implementation\n");
  
  list_t* ll = list_alloc();
  int i;
  //node_t* n = node_alloc(1); ** doesnt work **
  
//   for(i=0;i<5;i++){
//     list_add_to_back(ll,i);
//     //printf("Tests for lin");
//   }
//   list_print(ll);
//   int len = list_length(ll);
//   printf("len %d\n",len);
  
//   list_add_to_front(ll,-1);
//   list_print(ll);
//   len = list_length(ll);
//   printf("len %d\n",len);
  //list_free(ll);
  //node_free(ll->head);
//   list_add_at_index(ll, 2, 1);
//   list_print(ll);
  
//   list_remove_from_back(ll);
//   list_print(ll);
  
//   printf("removed :%d\n",list_remove_from_front(ll));
//   list_print(ll);
  
//   printf("removed :%d\n",list_remove_at_index(ll,1));
//   list_print(ll);
//   printf("element is in t/f %d\n",list_is_in(ll, 2));
//   printf("element is @ index: %d\n",list_get_elem_at(ll, 0));
//   printf("first index with given elem is @ index: %d\n",list_get_index_of(ll, 100));
  
  
  
  

  return 0;
}