// list/list.c
// 
// Implementation for linked list.
//
// <Author>

#include <stdio.h>
#include <stdlib.h>
//#include <string.h>
#include "list.h"

list_t *list_alloc() { 
  list_t* list = (list_t*) malloc(sizeof(list_t));
  list->head = NULL;
  return list;
}

node_t *node_alloc(elem val) {
  node_t* node = (node_t*) malloc(sizeof(node_t));
  node->value = val;
  node->next = NULL;
  return node;
}

void node_free(node_t *n) {
  free(n);
}

void list_free(list_t *l) {
  node_t *curr = l->head;
  node_t *temp = NULL;
  while (curr != NULL){
     temp = curr->next;
     node_free(curr);
     curr = temp;
   }
}

void list_print(list_t *l) {
  
  printf("entire list ...\n");
  node_t *curr = l->head;
  while (curr != NULL){
     printf("%d\n",curr->value);
     curr = curr->next;
   }
}

int list_length(list_t *l) { 
  int len = 0;
  node_t *curr = l->head;
  while (curr != NULL){
     len = len + 1;
     curr = curr->next;
   }
  
  return len;
}

void list_add_to_back(list_t *l, elem value) {
  node_t *curr = l->head;
  node_t *new_node;
  new_node = node_alloc(value);
  new_node->next = NULL;
  if(curr == NULL){
    l->head = new_node;
  }
  else{
    while (curr->next != NULL){
     curr = curr->next;
   }
  curr->next = new_node;
  }
  
}
void list_add_to_front(list_t *l, elem value) {
  node_t *new_head = node_alloc(value);
  node_t *head = l->head;
  new_head->next = head;
  l->head = new_head;
  
}
void list_add_at_index(list_t *l, elem value, int index) {
  if (index ==0){
    return list_add_to_front(l,value);
  }
  if (index >= list_length(l)){
    return list_add_to_back(l,value);
  }
  int idx = 0;
  node_t *temp = NULL;
  node_t *curr = l->head;
  while (idx < index-1){
     curr = curr->next;
     idx = idx+1;
   }
  temp = curr->next;
  curr->next = node_alloc(value);
  curr = curr->next;
  curr->next = temp;
}

elem list_remove_from_back(list_t *l) {
  node_t *curr = l->head;
  while (curr->next->next != NULL){
     curr = curr->next;
   }
  node_t *temp = curr->next;
  curr->next = NULL;
  //node_free(temp);
  return temp->value;
}
elem list_remove_from_front(list_t *l) { 
  node_t *curr = l->head;
  node_t *temp = curr->next;
  l->head = temp;
//   node_free(curr);
  return curr->value;
}
elem list_remove_at_index(list_t *l, int index) { 
  if (index ==0){
    return list_remove_from_front(l);
  }
  if (index >= list_length(l)){
    return list_remove_from_back(l);
  }
  int idx = 0;
  node_t *temp = NULL;
  node_t *curr = l->head;
  while (idx < index-1){
     curr = curr->next;
     idx = idx+1;
   }
  //curr is node before remove
  //temp is 2nd set of nodes
  temp = curr->next->next;
  node_t *del = curr->next;
  del->next = NULL;
  //node_free(del);
  curr->next = temp;
  return del->value;
}

bool list_is_in(list_t *l, elem value) {
  node_t *curr = l->head;
  while (curr != NULL){
     if (curr->value == value){
       return true;
     }
     curr = curr->next;
   }
  return false;
}
elem list_get_elem_at(list_t *l, int index) {
  if (index < 0){
    return -1;
  }
  int idx = 0;
  node_t *curr = l->head;
  while (curr != NULL){
     if (idx == index){
       return curr->value;
     }
     curr = curr->next;
     idx = idx + 1;
   }
  return -1;
}

int list_get_index_of(list_t *l, elem value) {
  int idx = 0;
  node_t *curr = l->head;
  while (curr != NULL){
     if (curr->value == value){
       return idx;
     }
     curr = curr->next;
     idx = idx + 1;
   }
  return -1;
}
